parameter   = load('Tokamak_parameter.dat');
res   = load('res_vs_t.dat');

%input parameter
R0				= parameter(1);
a				= parameter(2);
B0				= parameter(3);
omega_A			= parameter(4);
A				= parameter(5);
n				= parameter(6);
deltaB_R_max	= parameter(7);
deltaE_R_max	= parameter(8);
v_A				= parameter(9);


N_t   = size(res);
N     = (N_t(2)-1)/7;
T     = N_t(1);

for i=1:N
    X{i} = ones(10,T);
end
for i=1:N
    for j=1:T
        R     = res(j,1+(i-1)*7);
        Z     = res(j,2+(i-1)*7);
        phi   = res(j,3+(i-1)*7);
        v_par = res(j,4+(i-1)*7);
        p_phi = res(j,5+(i-1)*7);
        K     = res(j,6+(i-1)*7);
        id    = res(j,7+(i-1)*7)+1;
        t = res(j,N_t(2));
        PHI = n*phi - omega_A*t;
        while(PHI > 2*pi)
            PHI = PHI - 2*pi;
        end
        while(PHI < 0)
            PHI = PHI + 2*pi;
        end
        X{id}(1,j)  = PHI;
        X{id}(2,j)  = p_phi;
        X{id}(3,j)  = R;
        X{id}(4,j)  = Z;
        X{id}(5,j)  = v_par;
        X{id}(6,j)  = t;
    end
end




k = zeros(1,N);
%get mid-plane value(Z=0,R>R0)
for i=1:N
    for j=1:T-1
        if((X{i}(4,j) > 0 && X{i}(4,j+1) < 0) && X{i}(3,j)>R0)
           k(i) = k(i) + 1;
           weight = X{i}(4,j)/(X{i}(4,j) - X{i}(4,j+1));
           Y{i}(1,k(i)) = X{i}(1,j);
           if(X{i}(1,j) > pi)
               Y{i}(1,k(i)) = Y{i}(1,k(i)) -2*pi;%PHI
           end
           Y{i}(2,k(i)) = (1-weight)*X{i}(2,j)+weight*X{i}(2,j+1);;%p_phi
           Y{i}(3,k(i)) = (1-weight)*X{i}(3,j)+weight*X{i}(3,j+1);;%R
           Y{i}(4,k(i)) = (1-weight)*X{i}(4,j)+weight*X{i}(8,j+1);;%v_par
        elseif((X{i}(4,j) < 0 && X{i}(4,j+1) > 0) && X{i}(3,j)>R0)
          k(i) = k(i) + 1;
          weight = X{i}(4,j)/(X{i}(4,j) - X{i}(4,j+1));
          Y{i}(1,k(i)) = X{i}(1,j);
           if(X{i}(1,j+1) > pi)
               Y{i}(1,k(i)) = Y{i}(1,k(i))  - 2*pi;%PHI
           end
           Y{i}(2,k(i)) = (1-weight)*X{i}(2,j)+weight*X{i}(2,j+1);;%p_phi
           Y{i}(3,k(i)) = (1-weight)*X{i}(3,j)+weight*X{i}(3,j+1);;%R
           Y{i}(4,k(i)) = (1-weight)*X{i}(4,j)+weight*X{i}(8,j+1);;%v_par
        end
    end
end
for i=1:N
    subplot(2,2,1)
    plot(Y{i}(1,1:k(i)),Y{i}(2,1:k(i)),'.','Markersize',1);
    xlim([-pi pi]);
    xlabel('n\phi-\omega t')
    ylabel('P_\phi')
    hold on
    subplot(2,2,2)
    plot(Y{i}(1,1:k(i)),Y{i}(3,1:k(i)),'.','Markersize',1);
    xlim([-pi pi]);
    xlabel('n\phi-\omega t')
    ylabel('R')
    hold on
    subplot(2,2,3:4)
    plot(v_A*X{i}(6,:),X{i}(2,:));
    xlabel('time(\omega _A^{-1})')
    ylabel('P_\phi')
    i
    pause(2)
end