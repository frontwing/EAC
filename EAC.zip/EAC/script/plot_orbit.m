data        = load('particle_orbit.dat');
parameter   = load('Tokamak_parameter.dat');
SP_par	    = load('single_particle_parameter.dat');
p_phi       = load('p_phi.dat');
deltaE_par  = load('E_par.dat');
deltaB_par  = load('B_par.dat');
TAE_out     = load('TAE_out.dat');
initial     = load('initial.dat');

%input parameter
R0		= parameter(1);
a		= parameter(2);
B0		= parameter(3);
omega_A		= parameter(4);
A		= parameter(5);
n		= parameter(6);
deltaB_R_max	= parameter(7);
deltaE_R_max	= parameter(8);
v_A		= parameter(9);

omega_A = abs(omega_A);

%single particle motion
v_par = SP_par(4);
v_per = SP_par(5);
v = sqrt(v_par^2+v_per^2);
theta =0:0.01:2*pi;
X = a*cos(theta) + R0;
Z = a*sin(theta);
hold off;
plot(data(:,1),data(:,2));
hold on;
plot(X,Z,':','color','k');
xlim([R0-a-0.1 , R0+a+0.1]);
ylim([-a-0.1 a+0.1]); 
xlabel('R');
ylabel('Z');
str = strcat('v_per = ',num2str(v_per,'%5.2e'));
text (R0-a-0.03, a, str,'interpreter','tex');
str = strcat('\lambda = v_{||}/v = ',num2str(v_par/v,4));
text (R0-a-0.03, a-0.1, str,'interpreter','tex');
str = strcat('\omega_A = ',num2str(omega_A,'%5.2e'));
text (R0-a-0.03, a-0.2, str,'interpreter','tex');
str = strcat('Amplitude = ',num2str(A,4));
text (R0-a-0.03, a-0.3, str,'interpreter','tex');
str = strcat('n = ',num2str(n,4));
text (R0-a-0.03, a-0.4, str,'interpreter','tex');
str = strcat('v_{||} = ',num2str(v_par,4));
text (R0-a-0.03, a-0.5, str,'interpreter','tex');
axis square;
hold off;
print -dpng file.png;
print -deps file.eps
print -dps file.ps




%plot 3 components of P_phi
plot(data(:,7),data(:,6));
hold on;
plot(p_phi(:,5),p_phi(:,4),'color','red');
plot(p_phi(:,5),n/omega_A*p_phi(:,3),'color','green');
h = legend('P_{\phi} - n/\omega E','P_\phi','n/\omega E');
set(h,'Interpreter','tex') 
xlabel('time');
str = strcat('\omega_A = ',num2str(omega_A,'%5.2e'));
text (1, 2, str,'interpreter','tex');
str = strcat('\deltaB/B = ',num2str(A,4));
text (1, 1.9, str,'interpreter','tex');
hold off;
print -dpng P_phi.png
print -deps P_phi.eps
print -dps P_phi.ps
hold off;

%plot K = P_phi - n/\omega E
semilogy(data(:,7),abs(data(:,6)-data(1,6))/abs(data(1,6)));
xlabel('time');
ylabel('\Delta K/K');
h = legend(' P_\phi - n/\omega E = K');
set(h,'Interpreter','tex') 
print -dpng K.png;
hold off;

%plot Kinetic energy
plot(p_phi(:,5),p_phi(:,3),'color','green');
ylabel('Kinetic Energy');
xlabel('time');
print -dpng KE.png;
hold off;

%plot 3 components of P_phi
plot(p_phi(:,5),p_phi(:,3),'color','green');
hold on
plot(p_phi(:,5),p_phi(:,1),'color','red');
plot(p_phi(:,5),p_phi(:,2),'color','black');
plot(p_phi(:,5),p_phi(:,2)+p_phi(:,1),'color','blue');
xlabel('time');
ylabel('component of P_\phi');
h = legend('n/\omega E','e\psi','mRv_{||}B_\phi/B','e\psi + mRv_{||}B_\phi/B');
set(h,'Interpreter','tex') 
print -dpng p_phi_component.png;
hold off;


%plot P_phi
plot(p_phi(:,5),p_phi(:,4),'color','red');
ylabel('P_phi');
xlabel('time');
print -dpng Pphi.png;
hold off;

%plot Delta P_phi
plot(p_phi(:,5),abs(p_phi(:,4)-p_phi(1,4))/abs(p_phi(1,4)),'color','red');
ylabel('\DeltaP_\phi/P_\phi');
xlabel('time');
print -dpng DeltaP_phi.png;

%plot 2 components of K = P_\phi - n/\omega E
clf;
subplot(4,1,1);
plot(p_phi(:,5),p_phi(:,3)*n/omega_A,'color','green');
ylabel('n/\omega(1/2mv_{||}^2 + \mu B + e\delta \Phi)');
xlabel('time');
subplot(4,1,2);
plot(p_phi(:,5),p_phi(:,4),'color','red');
ylabel('P_\phi');
xlabel('time');
subplot(4,1,3);
plot(data(:,7),data(:,6),'color','blue');
ylabel('P_\phi - n/\omegaE');
xlabel('time');
subplot(4,1,4);
plot(data(:,7),data(:,6)-data(1,6),'color','blue');
ylabel('\Delta(P_\phi - n/\omegaE)');
xlabel('time');
print -dpng P_phi&KE.png;

%plot E-field on partile
clf;
plot(deltaE_par(:,2),deltaE_par(:,1) ,'color','blue');
ylabel('\deltaE_R_{particle}');
xlabel('time');
print -dpng deltaE_par.png;

%plot B-field on partile
clf;
plot(deltaB_par(:,2),deltaB_par(:,1) ,'color','blue');
ylabel('d\deltaB_R_{particle}');
xlabel('time');
print -dpng deltaB_par.png;
clf;

%plot Input TAE Mode Structure
[ndat mode_number] = size(TAE_out);
m_min = -3;
str = cell(mode_number,1);
norm_psi = linspace(0,1,ndat);
for i=1:mode_number
    plot(norm_psi,TAE_out(:,i) ,'color',[rand(1) rand(1) rand(1)]);
    hold on;
    str{i} = strcat('m = ',num2str(i-1+m_min));
end
legend(str);
ylabel('\xi_\psi');
xlabel('\sqrt{\psi}');
hold off;
print -dpng TAE_out.png;

%plot 3 components of P_phi
clf;
subplot(3,1,1);
plot(p_phi(:,5),p_phi(:,1),'color','green');
ylabel('e\psi');
xlabel('time');
subplot(3,1,2);
plot(p_phi(:,5),p_phi(:,2),'color','red');
ylabel('mv_{||}RB_\phi/B');
xlabel('time');
subplot(3,1,3);
plot(p_phi(:,5), p_phi(:,1)+ p_phi(:,2),'color','blue');
ylabel('P_phi');
xlabel('time');
print -dpng P_phi&compont.png;


clf;
%plot unperturbed P_phi 
hold off;
semilogy(data(:,7),abs(data(:,5)-data(1,5))/abs(data(1,5)));
ylabel('\Delta P_\phi_{ unperturbed}/P_\phi_{ unperturbed}');
xlabel('time');
print -dpng P_phi_unperturbed.png;


%initial position
clf;
hold off;
plot(initial(:,1),initial(:,2),'.','Markersize',1);
hold on;
plot(X,Z,':','color','k');
xlim([R0-a-0.1 , R0+a+0.1]);
ylim([-a-0.1 a+0.1]); 
xlabel('R');
ylabel('Z');
axis square;
print -dpng initial_position.png;


%initial velocity
clf;
hold off;
plot(initial(:,4),initial(:,5),'.','Markersize',1);
hold on;
xlabel('v_{par}');
ylabel('v_{per}');
print -dpng initial_velocity.png;


%Wave amplitude evolution
clf;
figure
hold off;
amp = load('amplitude.dat');
dt = amp(2,5) - amp(1,5);
%semilogy(amp(:,5)*(v_A/R0),sqrt(amp(:,1).^2+amp(:,2).^2)*deltaB_R_max/B0);
T_start = 5*int32(round(2*pi/omega_A)/dt +1);
T_end   = length(amp); 
%gamma_L = mean(diff(log(sqrt(amp(T_start:T_end,1).^2+amp(T_start:T_end,2).^2))))/dt;
gamma_L = diff(log(sqrt(amp(:,1).^2+amp(:,2).^2)))/dt;
gamma_L(T_end) = gamma_L(T_end-1);
amplitude = sqrt(amp(:,1).^2+amp(:,2).^2);
time      = amp(:,5)*(v_A/R0);
[AX,H1,H2] = plotyy(time,amplitude*deltaB_R_max/B0,time,gamma_L/(v_A/R0)*100,'semilogy','plot');
%str = strcat('\gamma _L/\omega _A  =  ',num2str(gamma_L/(v_A/R0)*100,8),' %');
str = strcat('\omega_{WAVE} = ',num2str(omega_A/(v_A/R0)),' \omega _A');
h = legend(str,2);
%text (10,1e-4,str,'interpreter','tex');
xlabel('time(\omega_A ^{-1})');
set(get(AX(1),'Ylabel'),'String','\deltaB_R/B_0') 
set(get(AX(2),'Ylabel'),'String','\gamma _L/\omega _A(%)') 
print -dpng amp.png
hold off;

%fitting linear growth rate
fit_region  = 700:2000; 
amp_fit     = amplitude(fit_region);
time_fit    = time(fit_region);
log_amp_fit = log(amp_fit);
p           = polyfit(time_fit,log_amp_fit,1);
plot(time_fit,amp_fit);
hold on
plot(time_fit, exp(p(1)*time_fit+p(2)),'--','color','red');
xlabel('time(\omega_A ^{-1})');
ylabel('Amplitude');
str = strcat('A = ',num2str(exp(p(2)),'%3.1e'),'*exp(',num2str(p(1),'%8.5f'),'*t)');
h = legend('Amplitude',str);
set(h,'Interpreter','tex')
print -dpng amp_fit.png
hold off;


%initial distubution function
clf;
hold off;
f     = load('f.dat');
plot(f(:,2),f(:,1),'.');
xlabel('r');
ylabel('f');
print -dpng f_vs_r.png
hold off;
plot(f(:,3),f(:,1),'.');
xlabel('v');
ylabel('f');
print -dpng f_vs_v.png
hold off;
plot(f(:,4),f(:,1),'.');
xlabel('p_\phi');
ylabel('f');
print -dpng f_vs_p_phi.png


%initial q profile
hold off;
q = load('q.dat');
plot(q(:,2),q(:,1));
xlabel('r');
ylabel('q');
title('Safety factor');
print -dpng q.png

%initial psi profile
hold off;
psi = load('psi.dat');
plot(psi(:,2),psi(:,1));
xlabel('r');
ylabel('psi');
title('poidal flux');
print -dpng psi.png

%initial deltaPhi profile
hold off;
deltaPhi = load('deltaPhi.dat');
plot(deltaPhi(1,:),deltaPhi(6,:) ,'color','black');
hold on;
plot(deltaPhi(1,:),deltaPhi(7,:) ,'color','red');
h = legend('m=1','m=2');
for i=2:5
plot(deltaPhi(1,:),deltaPhi(i,:) ,'color','blue');
end
for i=8:24
plot(deltaPhi(1,:),deltaPhi(i,:) ,'color','blue');
end
xlim([0 a]);

xlabel('r');
ylabel('\delta \Phi _{mn}');
print -dpng deltaPhi_initia.png


%initial beta profile
hold off;
beta = load('beta.dat');
plot(beta(:,2),beta(:,1),'color','black');


xlabel('r');
ylabel('fast ion \beta');
print -dpng beta.png


%initial distrubution function
hold off;
f_vs_v = load('f_vs_v.dat');
plot(f_vs_v(:,2)/v_A,f_vs_v(:,1),'.');

xlabel('v/v_A');
ylabel('f(v)');
print -dpng f_vs_v_initia.png

hold off;
f_vs_p_phi = load('f_vs_p_phi.dat');
plot(f_vs_p_phi(:,2),f_vs_p_phi(:,1),'.');

xlabel('p_\phi');
ylabel('f(p_\phi)');
print -dpng f_vs_p_phi_initia.png





%initial phi_field , Xi and B_field
Xi_initia = load('Xi_initia.dat');
[mZ mR] = size(Xi_initia);
R = linspace(R0-a,R0+a,mR);
Z = linspace(-a,+a,mZ);
contourf(R,Z,Xi_initia,30);
theta =0:0.01:2*pi;
X = a*cos(theta) + R0;
Z = a*sin(theta);
hold on;
plot(X,Z,':','color','k');
hold off;
xlabel('R');
ylabel('Z');
title('\xi \cdot \nabla \psi');
axis square;
print -dpng Xi_initia.png

phi_field_initia = load('phi_field_initia.dat');
[mZ mR] = size(phi_field_initia);
R = linspace(R0-a,R0+a,mR);
Z = linspace(-a,+a,mZ);
contourf(R,Z,phi_field_initia,30);
theta =0:0.01:2*pi;
X = a*cos(theta) + R0;
Z = a*sin(theta);
hold on;
plot(X,Z,':','color','k');
hold off;
xlabel('R');
ylabel('Z');
axis square;
print -dpng phi_field_initia.png

A_par_field_initia = load('A_par_field_initia.dat');
[mZ mR] = size(A_par_field_initia);
R = linspace(R0-a,R0+a,mR);
Z = linspace(-a,+a,mZ);
contourf(R,Z,A_par_field_initia,30);
theta =0:0.01:2*pi;
X = a*cos(theta) + R0;
Z = a*sin(theta);
hold on;
plot(X,Z,':','color','k');
hold off;
xlabel('R');
ylabel('Z');
axis square;
print -dpng A_par_field_initia.png


E_field_initia = load('E_field_initia.dat');
[mZ mR] = size(E_field_initia);
R = linspace(R0-a,R0+a,mR);
Z = linspace(-a,+a,mZ);
contourf(R,Z,E_field_initia,30);
colorbar;
theta =0:0.01:2*pi;
X = a*cos(theta) + R0;
Z = a*sin(theta);
hold on;
plot(X,Z,':','color','k');
hold off;
xlabel('R');
ylabel('Z');
axis square;
print -dpng E_field_initia.png


B_field_initia = load('B_field_initia.dat');
[mZ mR] = size(B_field_initia);
R = linspace(R0-a,R0+a,mR);
Z = linspace(-a,+a,mZ);
contourf(R,Z,B_field_initia,30);
theta =0:0.01:2*pi;
X = a*cos(theta) + R0;
Z = a*sin(theta);
hold on;
plot(X,Z,':','color','k');
hold off;
xlabel('R');
ylabel('Z');
axis square;
print -dpng B_field_initia.png
 
hold off; 
E_field = load('E_field.dat');
subplot(2,1,1)
plot(E_field(:,4),E_field(:,2),'.');
hold on;
plot(E_field(:,4),E_field(:,3),'o');
h = legend('E_X','E_Y');
xlabel('time');
ylabel('E_X(Y)');
subplot(2,1,2)
plot(E_field(:,4),E_field(:,1),'.');
xlabel('time');
ylabel('E_{total}');
print -dpng E_field_vs_t.png

clf;
%check dpdt conservation
hold off; 
if(exist('dp_phidt.dat','file'))
	dpdt = load('dp_phidt.dat');
	plot(dpdt(:,3),dpdt(:,1),'color','red');
	hold on;
	plot(dpdt(:,3),dpdt(:,2),'color','blue');
	h = legend('P _\phi = dP_\phi/dt*dt','P_\phi');
	xlabel('time');
	print -dpng dp_phidt.png
end

%check dEdt conservation
hold off; 
if(exist('dEdt.dat','file'))
	dEdt = load('dEdt.dat');
	plot(dEdt(:,3),dEdt(:,1),'color','red');
	hold on;
	plot(dEdt(:,3),dEdt(:,2),'color','blue');
	h = legend('E = dE/dt*dt','E');
	xlabel('time');
	print -dpng dEdt.png
end

%check dKdt conservation
hold off; 
if(exist('dKdt.dat','file'))
	dEdt = load('dKdt.dat');
	plot(dKdt(:,3),dKdt(:,1),'color','red');
	hold on;
	plot(dKdt(:,3),dKdt(:,2),'color','blue');
	h = legend('K = dKdt*dt','K');
	xlabel('time');
	print -dpng dKdt.png
end


%plot poloidal flux psi(R,Z)
clf;
hold off;
psi_RZ	= load('psi_RZ.dat');
R	= load('R.dat');	
Z	= load('Z.dat');
contour(R,Z,psi_RZ,15,'black')
axis square
xlabel('R');
ylabel('Z');
print -dpng psi_RZ.png
