%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                         %
%         diagnostic for time evolution of mode amplitude                 %
%         original version written by J.Zhu 2010.4-2010.12                %
%                                                                         %
%           version 1:  written by J.Zhu 2011.8.25                        %
%           version 2:  written by J.Zhu 2011.12.5                        %
%           version 3:  written by J.Zhu 2012.6.1                         %
%                                                                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
parameter   = load('Tokamak_parameter.dat');

%input parameter
R0           = parameter(1);
a            = parameter(2);
B0           = parameter(3);
omega_A      = parameter(4);
A            = parameter(5);
n		     = parameter(6);
deltaB_R_max = parameter(7);
deltaE_R_max = parameter(8);
v_A          = parameter(9);

omega_A      = abs(omega_A);

amp          = load('amplitude.dat');
dt           = amp(2,5) - amp(1,5);
T_end        = length(amp); 
amplitude    = sqrt(amp(:,1).^2+amp(:,2).^2);
time         = amp(:,5)*(v_A/R0);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%plot amplitude vs time
figure(1)
semilogy(time,amplitude,'LineWidth',4);
str = strcat('$\omega_{WAVE} = ',num2str(omega_A/(v_A/R0)),'\omega _A$');
h = legend(str);
%set(h,'FontSize',24,'YColor',[1 1 1],'XColor',[1 1 1],'Interpreter','latex','FontSize',24);
xlabel('time$(\omega_A ^{-1})$','Interpreter','latex','FontSize',36);
ylabel('Amplitude','Interpreter','latex','FontSize',36);
set(gca,'FontSize',36);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%do linear fitting for amplitude to get linear growth rate and plot amplitude vs time
figure(2)
%fitting linear growth rate
fit_region  = 700:2000; 
amp_fit     = amplitude(fit_region);
time_fit    = time(fit_region);
log_amp_fit = log(amp_fit);
p           = polyfit(time_fit,log_amp_fit,1);
plot(time_fit,amp_fit,'LineWidth',4);
hold on
plot(time_fit, exp(p(1)*time_fit+p(2)),'--','color','red','LineWidth',4);
xlabel('time$(\omega_A ^{-1})$','Interpreter','latex','FontSize',36);
ylabel('Amplitude','Interpreter','latex','FontSize',36);
set(gca,'FontSize',36);
str = strcat('A = ',num2str(exp(p(2)),'%3.1e'),'*exp(',num2str(p(1),'%8.5f'),'*t) $\gamma _L$ = ',num2str(p(1)*100,'%5.3f'),'\%');
h = legend('Amplitude',str);
set(h,'Interpreter','latex','FontSize',24);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%plot time evolution of amplitude and linear growth rate
figure(3)
T_start = 5*int32(round(2*pi/omega_A)/dt +1);
T_end   = length(amp); 
gamma_L = diff(log(sqrt(amp(:,1).^2+amp(:,2).^2)))/dt;
gamma_L(T_end) = gamma_L(T_end-1);
[AX,H1,H2] = plotyy(time,amplitude,time,gamma_L/(v_A/R0)*100,'semilogy','plot');
str = strcat('$\omega_{WAVE} = ',num2str(omega_A/(v_A/R0)),'\omega _A$');
%h = legend(str,2);
%set(h,'FontSize',24,'YColor',[1 1 1],'XColor',[1 1 1],'Interpreter','latex','FontSize',24);
xlabel('time$(\omega_A ^{-1})$','Interpreter','latex','FontSize',36);
set(get(AX(1),'Ylabel'),'String','Amplitude','Interpreter','latex','FontSize',36);
set(get(AX(2),'Ylabel'),'String','$\gamma _L/\omega _A(\%)$','Interpreter','latex','FontSize',36);
set(AX,'FontSize',24);
set(H1,'LineWidth',4);
set(H2,'LineWidth',4);