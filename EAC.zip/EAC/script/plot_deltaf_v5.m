%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                         %
%     diagnostic for time evolution of delta_f in phase space             %
%                                                                         %
%           version 1:  written by J.Zhu 2011.11.25                       %
%           version 2:  written by J.Zhu 2012.03.21                       %
%           version 3:  written by J.Zhu 2012.07.31                       %
%           version 4:  written by J.Zhu 2013.10.21                       %
%           version 5:  written by J.Zhu 2013.10.26                       %
%                                                                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%set file path
%the mode evolution is to be investigated 
folder_name  = '2013.10.30_n=2_beta=0.012_gamma_d=0.014_Lambda_=0.50_out_put_delta_f_2000w';

current_folder  = pwd;
resonant_folder = pwd;

%current frequency/initial frequency
coeff_omega = 0.577;

%whether use smooth method
SMOOTH = true;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%grid in E-P_phi phase space
L           = 100;%how many grid in P_phi and E
Lambda_0    = 0.50;
E_0         = 1.0;%unit : v_A*v_A;
T           = 13;
ZZ          = zeros(L,L);
eps         = 1e-3;%if dot{Phase} is small than eps , it can be recognized as ZERO!!

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% resonant condition : dot{PHI} = n*<dot{phi}> + p*omega_b + omega +
% (<dot{alpha})> = 0, p is integer number.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

orbit_folder_name  = strcat('2013.11.04_particle_orbit_frquency_Lambda=',num2str(Lambda_0, '%3.2f'),'_counter_passing');
orbit_folder_name  = strcat('2013.10.25_particle_orbiy_frquency_Lambda=',num2str(Lambda_0, '%3.2f'),'_CPN_n=2_frequency_of_phase_T_START=2000');

%region of p
p_start = 2;
p_end   = 3;

%Calculate Phase including Nonlinear terms (true) or not(false)
CPN     = false;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Calculate resonant condition in E-P_phi phase space
% resonant condition : dot{PHI} = n*<dot{phi}> + p*omega_b + omega +
% (<dot{alpha})> = 0, p is integer number.

cd(resonant_folder)
cd(orbit_folder_name)

data_of    = load('oribt_frequency.dat');
if(CPN)
    data_of_CPN= load('oribt_frequency_CPN.dat');
end

cd(current_folder)


[N w]           = size(data_of);
P_phi           = data_of(:,1);
E               = data_of(:,2);
omega_phi       = data_of(:,3);
omega_theta     = data_of(:,4);
if(CPN)
    omega_alpha     = data_of_CPN(:,3);
end

E_min           = min(E);
E_max           = max(E);
P_phi_min     	= min(P_phi);
P_phi_max     	= max(P_phi);

Y =linspace(P_phi_min,P_phi_max,L);
X =linspace(E_min,E_max,L);
dE     = (E_max - E_min)/(L-1);
dP_phi = (P_phi_max - P_phi_min)/(L-1);

OMEGA_PHI       = zeros(L,L);
OMEGA_THETA     = zeros(L,L);
if(CPN)
    OMEGA_ALPHA     = zeros(L,L);
end
OMEGA_NUM       = zeros(L,L);
weight_line     = zeros(2,2);
weight_square   = zeros(2,2);

for i=1:N
    %do not use particles that are out of boundary!
    if(abs(omega_phi(i)) < 1e-10)
        continue;
    end
    
    index_E          = floor((E(i)-E_min)/dE) + 1;
    index_P_phi      = floor((P_phi(i)-P_phi_min)/dP_phi) + 1;
    EE               = E_min     + (double(index_E)-1)*dE;
    PP               = P_phi_min + (double(index_P_phi)-1)*dP_phi;
    weight_line(1,1) = (P_phi(i) - PP)/dP_phi;
    weight_line(2,1) = (E(i) - EE)/dE;
    %treating boundary condition
    if(index_P_phi == L)
        index_P_phi = L-1;
        weight_line(1,1) = 1;
    end
    if(index_E == L)
        index_E = L-1;
        weight_line(2,1) = 1;
    end

    weight_line(1,2) = 1 - weight_line(1,1);
    weight_line(2,2) = 1 - weight_line(2,1);
    for ii=1:2
        for jj=1:2
            weight_square(ii,jj)                       = weight_line(1,3-ii)*weight_line(2,3-jj);
            OMEGA_PHI(index_P_phi-1+ii,index_E-1+jj)   = OMEGA_PHI(index_P_phi-1+ii,index_E-1+jj)   + omega_phi(i)*weight_square(ii,jj);
            OMEGA_THETA(index_P_phi-1+ii,index_E-1+jj) = OMEGA_THETA(index_P_phi-1+ii,index_E-1+jj) + omega_theta(i)*weight_square(ii,jj);
            if(CPN)
                OMEGA_ALPHA(index_P_phi-1+ii,index_E-1+jj) = OMEGA_ALPHA(index_P_phi-1+ii,index_E-1+jj) + omega_alpha(i)*weight_square(ii,jj);
            end
            OMEGA_NUM(index_P_phi-1+ii,index_E-1+jj)   = OMEGA_NUM(index_P_phi-1+ii,index_E-1+jj)   + 1.0*weight_square(ii,jj);
        end
    end
end
for i=1:L
    for j=1:L
        if(OMEGA_NUM(i,j) == 0)
            OMEGA_NUM(i,j) = 1;
        end
    end
end

OMEGA_PHI   = OMEGA_PHI./OMEGA_NUM;
OMEGA_THETA = OMEGA_THETA./OMEGA_NUM;
if(CPN)
    OMEGA_ALPHA = OMEGA_ALPHA./OMEGA_NUM;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%plot delta-f structure in E-P_phi phase space

cd(current_folder)
cd(folder_name);

file_name	  = strcat('delta-f_vs_E&P_phi_vs_Time_',num2str(T),'_Lambda=', num2str(Lambda_0, '%3.2f'),'.dat');
parameter     = load('Tokamak_parameter.dat');
amp           = load('amplitude.dat');
R0		      = parameter(1);
omega_A		  = parameter(4);
n             = parameter(6);
v_A		      = parameter(9);

omega_A       = abs(omega_A);

t_end         = amp(length(amp),5);
data          = load(file_name);
cd ..

[N w]         = size(data);
deltaf        = data(:,1);
E             = data(:,2);
P_phi         = data(:,3);
v             = data(:,4);
R             = data(:,5);
f             = data(:,6);

c_min         = min(deltaf);
c_max         = max(deltaf);

Z             = zeros(L,L);
F             = zeros(L,L);
num           = zeros(L,L);
weight_line   = zeros(2,2);
weight_square = zeros(2,2);
 nnnnn = 0;
for i=1:N
    if(E(i) > E_min && E(i) < E_max && P_phi(i) > P_phi_min && P_phi(i) < P_phi_max)
        nnnnn = nnnnn + 1;
        index_E = floor((E(i)-E_min)/dE) + 1;
        index_P_phi = floor((P_phi(i)-P_phi_min)/dP_phi) + 1;
        EE = E_min     + (double(index_E)-1)*dE;
        PP = P_phi_min + (double(index_P_phi)-1)*dP_phi;
        weight_line(1,1) = (P_phi(i) - PP)/dP_phi;
        weight_line(2,1) = (E(i) - EE)/dE;
        %treating boundary condition
        if(index_P_phi == L)
            index_P_phi = L-1;
            weight_line(1,1) = 1;
        end    
        if(index_E == L)
            index_E = L-1;
            weight_line(2,1) = 1;
        end
        weight_line(1,2) = 1 - weight_line(1,1);
        weight_line(2,2) = 1 - weight_line(2,1);
        for ii=1:2
            for jj=1:2
                weight_square(ii,jj)               = weight_line(1,3-ii)*weight_line(2,3-jj);
                Z(index_P_phi-1+ii,index_E-1+jj)   = Z(index_P_phi-1+ii,index_E-1+jj)   + deltaf(i)*weight_square(ii,jj);
                F(index_P_phi-1+ii,index_E-1+jj)   = F(index_P_phi-1+ii,index_E-1+jj) +        f(i)*weight_square(ii,jj);
                num(index_P_phi-1+ii,index_E-1+jj) = num(index_P_phi-1+ii,index_E-1+jj) +       1.0*weight_square(ii,jj);
            end
        end
    end
end
for i=1:L
    for j=1:L
        if(num(i,j) == 0)
            num(i,j) = 1;
        end
    end
end
subplot(3,2,[1 3 5]);

Z  = Z./num;
ZZ = Z;
%define boundary to be NaN
for i=1:L
    for j=1:L
        if(Z(i,j) == 0)
            ZZ(i,j) = NaN;
        end
    end
end

if(SMOOTH)
    c=Z;
    cc=Z;    
    [mm,nn] = size(Z);
    for i=1:nn
        c(:,i) = smooth(Z(:,i));
    end
    for j=1:mm
        cc(j,:) = smooth(c(j,:));
    end
    %define boundary to be NaN
    for i=1:L
        for j=1:L
            if(Z(i,j) == 0)
                cc(i,j) = NaN;
            end
        end
    end
    contourf(X/v_A/v_A,Y,cc,35,'LineStyle','none');
else
    contourf(X/v_A/v_A,Y,ZZ,35,'LineStyle','none');
end
%caxis([-2e-3 2e-3])
%colorbar('location','eastoutside')
xlabel('$E(v_A^2)$','Interpreter','latex','FontSize',28)
ylabel('$P_\phi$','Interpreter','latex','FontSize',28)
str = ['$\delta f$ ($\omega_{\rm n=',num2str(n),'}$=',num2str(omega_A/(v_A/R0),'%3.3f'),'$\omega _A$',', $\Lambda _0$=',num2str(Lambda_0),')'];
title(str,'Interpreter','latex','FontSize',28)
set(gca,'FontSize',18);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%compute resonant line
E_res       =  zeros(p_end-p_start+1,L);
P_phi_res   =  zeros(p_end-p_start+1,L);
G           =  zeros(p_end-p_start+1);%index of E_res
for p=p_start:p_end
    %Phase
    if(CPN)
        PHI     =  n*OMEGA_PHI + p*OMEGA_THETA + omega_A - OMEGA_ALPHA;
    else
        PHI     =  n*OMEGA_PHI + p*OMEGA_THETA + coeff_omega*omega_A;
    end
    %get exact resonance line
    for i=1:L
        E_res_temp = 0;
        NUM_E_res  = 0;
        for j=1:L
            if(abs(PHI(i,j)) < eps && abs(PHI(i,j)) > 0)
                NUM_E_res    = NUM_E_res +1;
                E_res_temp   = E_res_temp + X(j);
            end
        end
        if(NUM_E_res ~= 0)
            G(p-p_start+1) = G(p-p_start+1)+1;
            E_res_temp    = E_res_temp/NUM_E_res; 
            E_res(p-p_start+1,G(p-p_start+1))      = E_res_temp;
            P_phi_res(p-p_start+1,G(p-p_start+1))  = Y(i);            
        end
    end
end
%plot resonant line in E-P_phi phase space!
hold on
for p=p_start:p_end
    if(G(p-p_start+1) ~= 0)
        plot(E_res(p-p_start+1,1:G(p-p_start+1))/v_A/v_A,P_phi_res(p-p_start+1,1:G(p-p_start+1)),'Linewidth',4,'Color','white','Linestyle','--');
        str  =  strcat(' \leftarrow p=',num2str(p));
        x_position = E_res(p-p_start+1,floor(G(p-p_start+1)/2)+1)/v_A/v_A;
        y_position = P_phi_res(p-p_start+1,floor(G(p-p_start+1)/2)+1);
        text(x_position,y_position,str,'FontSize',18)
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%plot distrubution function f vs. P_phi
subplot(3,2,2);
E_0_index = floor((E_0*v_A*v_A-E_min)/dE) + 1;
plot(Y,F(:,E_0_index)./num(:,E_0_index),'Linewidth',3)
hold on;
plot(Y,(F(:,E_0_index)-Z(:,E_0_index).*num(:,E_0_index))./num(:,E_0_index),'--','Linewidth',3,'Color','black')
xlim([P_phi_min P_phi_max]);
str = strcat('$f(t=',num2str(T*t_end/20*(v_A/R0),'%6.0f'),'\omega _A ^{-1})$');
h = legend(str,'$f(t=0)$');
set(h,'Interpreter','latex','FontSize',24);
xlabel('$P_\phi$','Interpreter','latex','FontSize',24)
ylabel('$f(P_\phi)$ (a.u.)','Interpreter','latex','FontSize',24)
set(gca,'FontSize',18);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%mode amplitude
subplot(3,2,4);
dt           = amp(2,5) - amp(1,5);
T_end        = length(amp); 
amplitude    = sqrt(amp(:,1).^2+amp(:,2).^2);
time         = amp(:,5)*(v_A/R0);


%plot amplitude vs time
semilogy(time,amplitude,'LineWidth',3);
xlabel('time$(\omega_A ^{-1})$','Interpreter','latex','FontSize',24);
ylabel('Amplitude','Interpreter','latex','FontSize',24);
set(gca,'FontSize',18);
yy = get(gca,'Ylim');
hold on
y = linspace(yy(1),yy(2),1000);
x = T*t_end/20*(v_A/R0);
plot(x+0*y,y,'--','Linewidth',3,'Color','black')
str = ['Amplitude evolution (t=',num2str(T*t_end/20*(v_A/R0),'%4.0f'),'$\omega _A ^{-1}$)'];
title(str,'Interpreter','latex','FontSize',24)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%plot frequency vs. time
subplot(3,2,6);
%do Fourier transform for time evolution of mode amplitude with moving FFT window

%how many wave period to sample
nmode = 45;
%how many dt to do fft
%redifine dt in order to reduce file size
mstep = 10;
[T L] = size(amp);
temp = amp(1:mstep:T,:);
amp  = temp;

dt = amp(2,5) - amp(1,5);
windows_width = int32(nmode*(2*pi/omega_A)/dt);
t = amp(:,5);
X = amp(:,1);
Y = amp(:,2);
E = X.*cos(omega_A*t)+Y.*sin(omega_A*t);
t_end = length(amp)-1;
omega_end = 96;
omega_vs_t = zeros(omega_end,t_end-windows_width);
for i=1:t_end-windows_width
    E_vs_omega = abs(fft(E(i:windows_width+i-1)));
    omega_vs_t(:,i)  = E_vs_omega(1:omega_end);
end


%plot frequency vs time
t = t*v_A;
omega_fft = 1:omega_end;
omega_fft = (omega_fft-1)*2*pi/dt/(double(windows_width)-1)/v_A;
contourf(t(windows_width+1:t_end),omega_fft/omega_A*v_A,omega_vs_t,30,'Linestyle','none')
xlabel('time$(\omega_A ^{-1})$','Interpreter','latex','FontSize',24)
ylabel('$\omega/\omega _{t=0}$','Interpreter','latex','FontSize',24)
set(gca,'FontSize',18);