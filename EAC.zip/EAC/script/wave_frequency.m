parameter   = load('Tokamak_parameter.dat');
amp = load('amplitude.dat');


%input parameter
R0              = parameter(1);
a               = parameter(2);
B0              = parameter(3);
omega_A         = parameter(4);
A               = parameter(5);
n               = parameter(6);
deltaB_R_max    = parameter(7);
deltaE_R_max    = parameter(8);
v_A             = parameter(9);

omega_A = abs(omega_A);

%how many wave period to sample
nmode = 15;
dt = amp(2,5) - amp(1,5);
windows_width = int32(nmode*(2*pi/omega_A)/dt);
t = amp(:,5);
X = amp(:,1);
Y = amp(:,2);
E = X.*sin(omega_A*t)+Y.*cos(omega_A*t);
t_end = length(amp)-1;
omega_end = 32;
omega_vs_t = zeros(omega_end,t_end-windows_width);
for i=1:t_end-windows_width
    E_vs_omega = abs(fft(E(i:windows_width+i-1)));
    [A index] = max(E_vs_omega(1:windows_width/2));
    omega_t(i) = (index-1)*2*pi/dt/(double(windows_width)-1);
    omega_vs_t(:,i)  = E_vs_omega(1:omega_end);
end
t = t*v_A;
subplot(2,2,1)
plot(t(windows_width+1:t_end),omega_t/omega_A)
xlabel('time(\omega_A ^{-1})')
ylabel('\omega/\omega_{wave}')
%ylim([1,1.1])
xlim([t(windows_width) t(t_end)])
subplot(2,2,2)
plot(t,X)
xlabel('time(\omega_A ^{-1})')
ylabel('X')
subplot(2,2,3)
plot(t,Y)
xlabel('time(\omega_A ^{-1})')
ylabel('Y')
subplot(2,2,4)
semilogy(t,sqrt(X.^2+Y.^2))
xlabel('time(\omega_A ^{-1})')
ylabel('Amplitude')

% control the image pixel size by manipulating the paper size and number of dots per inch
output_size = [5000 3000];%Size in pixels
resolution = 300;%Resolution in DPI
set(gcf,'paperunits','inches','paperposition',[0 0 output_size/resolution]);

% use 300 DPI
print('frequency_vs_t','-dpng',['-r' num2str(resolution)]);
hold off
clf
figure1 = figure();
axes1 = axes('Parent',figure1,'Layer','top','FontSize',24);
box(axes1,'on');
hold(axes1,'all');
output_size = [5000 3000];%Size in pixels
resolution = 300;%Resolution in DPI
set(gcf,'paperunits','inches','paperposition',[0 0 output_size/resolution]);

omega_fft = 1:omega_end;
omega_fft = (omega_fft-1)*2*pi/dt/(double(windows_width)-1)/v_A;
contourf(t(windows_width+1:t_end),omega_fft,omega_vs_t,25,'Linestyle','none')
xlabel('time(\omega_A ^{-1})','FontSize',32)
ylabel('\omega/\omega _A','FontSize',32)
print('omega_vs_time','-dpng')
hgsave('omega_vs_time.fig')
